import ttt00

text = '112.36.45.33'

print (ttt00.ipaddr(text))

